#ifndef ELEC_MOTOR_DRIVER_H
#define ELEC_MOTOR_DRIVER_H

#include <stdint.h>
#include <stdbool.h>

#include "esp_err.h"
#include "esp_twai.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint32_t id;
    uint8_t dlc;
    uint8_t data[8];
} elec_motor_can_rx_item_t;

void elec_motor_log_frame(const char *prefix, uint32_t id, const uint8_t *d, uint8_t dlc);

esp_err_t elec_motor_driver_init(twai_node_handle_t node_hdl,
                                 QueueHandle_t rxq_main,
                                 uint8_t node_id,
                                 const char *log_tag);

esp_err_t elec_motor_nmt_send(uint8_t cmd, uint8_t node);
esp_err_t elec_motor_sdo_write_u8(uint16_t idx, uint8_t sub, uint8_t v);
esp_err_t elec_motor_sdo_write_u16(uint16_t idx, uint8_t sub, uint16_t v);
esp_err_t elec_motor_sdo_write_u32(uint16_t idx, uint8_t sub, uint32_t v);

esp_err_t elec_motor_configure_rpdo1_map_controlword_only(void);
esp_err_t elec_motor_configure_rpdo2_map_target_velocity_only(void);
esp_err_t elec_motor_configure_rpdo2_map_target_velocity_and_cmd_polarity(void);
esp_err_t elec_motor_configure_rpdo2_map_target_position_only(void);
esp_err_t elec_motor_configure_rpdo2_map_target_position_and_speed(void);
esp_err_t elec_motor_configure_rpdo2_map_target_torque_only(void);
esp_err_t elec_motor_configure_tpdo1_map_statusword_only(void);
esp_err_t elec_motor_configure_tpdo2_map_current_only(void);
esp_err_t elec_motor_configure_tpdo2_map_position_only(void);
esp_err_t elec_motor_configure_tpdo2_inhibit_100hz(void);
esp_err_t elec_motor_configure_tpdo2_fast_event(void);
esp_err_t elec_motor_configure_tpdo3_map_velocity_only(void);
esp_err_t elec_motor_configure_tpdo3_fast_event(void);
esp_err_t elec_motor_configure_tpdo4_map_current_only(void);
esp_err_t elec_motor_configure_tpdo4_fast_event(void);

esp_err_t elec_motor_send_controlword(uint16_t cw);
esp_err_t elec_motor_send_target_velocity(int32_t vel);
esp_err_t elec_motor_send_target_velocity_and_cmd_polarity(int32_t vel, uint8_t cmd_pol);
esp_err_t elec_motor_send_target_position(int32_t pos_revs);
esp_err_t elec_motor_send_target_position_and_speed(float pos_revs, float speed_revs_per_sec);
esp_err_t elec_motor_send_target_torque(int16_t torque);

esp_err_t elec_motor_wait_and_print_tpdo1(uint32_t timeout_ms);
esp_err_t elec_motor_enable_operation_sequence(void);
esp_err_t elec_motor_enable_operation_sequence_position(void);
esp_err_t elec_motor_enable_position(void);

#ifdef __cplusplus
}
#endif

#endif
