#include "elec_motor_driver.h"

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <math.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_check.h"
#include "esp_log.h"

#define NMT_ID              0x000
#define SDO_WAIT_MS         400
#define TPDO1_WAIT_MS       400

static twai_node_handle_t s_node_hdl = NULL;
static QueueHandle_t s_rxq_main = NULL;
static uint8_t s_node_id = 0;
static const char *s_log_tag = "ELEC_MOTOR";

#define SDO_TX_ID           (0x600 + s_node_id)
#define SDO_RX_ID           (0x580 + s_node_id)
#define RPDO1_ID            (0x200 + s_node_id)
#define RPDO2_ID            (0x300 + s_node_id)
#define TPDO1_ID            (0x180 + s_node_id)

static uint16_t u16_le(const uint8_t *b) { return (uint16_t)(b[0] | (uint16_t)(b[1] << 8)); }
static uint32_t u32_le(const uint8_t *b) { return (uint32_t)(b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)); }

void elec_motor_log_frame(const char *prefix, uint32_t id, const uint8_t *d, uint8_t dlc)
{
    char buf[3 * 8 + 1] = {0};
    char *p = buf;
    for (int i = 0; i < dlc && i < 8; i++) {
        p += snprintf(p, (size_t)(buf + sizeof(buf) - p), "%02X ", d[i]);
    }
    ESP_LOGI(s_log_tag, "%s ID=0x%03" PRIX32 " DLC=%u DATA=[%s]", prefix, id, dlc, buf);
}

static esp_err_t ensure_init(void)
{
    if (!s_node_hdl || !s_rxq_main || s_node_id == 0) {
        return ESP_ERR_INVALID_STATE;
    }
    return ESP_OK;
}

static bool wait_for_id_main(uint32_t want_id, elec_motor_can_rx_item_t *out, uint32_t timeout_ms)
{
    TickType_t to = pdMS_TO_TICKS(timeout_ms);
    TickType_t start = xTaskGetTickCount();

    while ((xTaskGetTickCount() - start) < to) {
        elec_motor_can_rx_item_t item;
        TickType_t left = to - (xTaskGetTickCount() - start);
        if (xQueueReceive(s_rxq_main, &item, left) == pdTRUE) {
            if (item.id == want_id) {
                if (out) {
                    *out = item;
                }
                return true;
            }
            elec_motor_log_frame("RX (ignored)", item.id, item.data, item.dlc);
        }
    }
    return false;
}

static esp_err_t can_send(uint32_t id, const uint8_t *data, uint8_t dlc)
{
    ESP_RETURN_ON_ERROR(ensure_init(), s_log_tag, "Driver not initialized");

    if (dlc > 8) {
        dlc = 8;
    }

    twai_frame_t tx = {0};
    tx.header.id = id;
    tx.header.ide = false;
    tx.buffer = (uint8_t *)data;
    tx.buffer_len = dlc;

    elec_motor_log_frame("TX", id, data, dlc);
    return twai_node_transmit(s_node_hdl, &tx, portMAX_DELAY);
}

static esp_err_t sdo_write_8b(uint8_t cs, uint16_t idx, uint8_t sub, uint32_t payload_le)
{
    uint8_t d[8] = {0};
    d[0] = cs;
    d[1] = (uint8_t)(idx & 0xFF);
    d[2] = (uint8_t)(idx >> 8);
    d[3] = sub;
    d[4] = (uint8_t)(payload_le & 0xFF);
    d[5] = (uint8_t)((payload_le >> 8) & 0xFF);
    d[6] = (uint8_t)((payload_le >> 16) & 0xFF);
    d[7] = (uint8_t)((payload_le >> 24) & 0xFF);

    ESP_RETURN_ON_ERROR(can_send(SDO_TX_ID, d, 8), s_log_tag, "SDO tx failed");

    elec_motor_can_rx_item_t r = {0};
    if (!wait_for_id_main(SDO_RX_ID, &r, SDO_WAIT_MS)) {
        ESP_LOGE(s_log_tag, "SDO timeout idx=0x%04X sub=0x%02X", idx, sub);
        return ESP_ERR_TIMEOUT;
    }

    elec_motor_log_frame("RX (SDO)", r.id, r.data, r.dlc);

    if (r.dlc == 8 && r.data[0] == 0x80) {
        uint16_t ridx = (uint16_t)(r.data[1] | (r.data[2] << 8));
        uint8_t rsub = r.data[3];
        uint32_t acode = u32_le(&r.data[4]);
        ESP_LOGE(s_log_tag, "SDO ABORT idx=0x%04X sub=0x%02X code=0x%08" PRIX32, ridx, rsub, acode);
        return ESP_FAIL;
    }

    if (r.dlc == 8 && r.data[0] == 0x60 &&
        r.data[1] == (uint8_t)(idx & 0xFF) &&
        r.data[2] == (uint8_t)(idx >> 8) &&
        r.data[3] == sub) {
        return ESP_OK;
    }

    ESP_LOGW(s_log_tag, "Unexpected SDO response");
    return ESP_FAIL;
}

static void print_statusword(uint16_t sw)
{
    ESP_LOGI(s_log_tag,
             "SW=0x%04X | Rdy:%d SwOn:%d OpEn:%d Fault:%d QS:%d SoD:%d Warn:%d",
             sw,
             (sw >> 0) & 1,
             (sw >> 1) & 1,
             (sw >> 2) & 1,
             (sw >> 3) & 1,
             (sw >> 5) & 1,
             (sw >> 6) & 1,
             (sw >> 7) & 1);
}

esp_err_t elec_motor_driver_init(twai_node_handle_t node_hdl,
                                 QueueHandle_t rxq_main,
                                 uint8_t node_id,
                                 const char *log_tag)
{
    if (!node_hdl || !rxq_main || node_id == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    s_node_hdl = node_hdl;
    s_rxq_main = rxq_main;
    s_node_id = node_id;
    s_log_tag = (log_tag && log_tag[0] != '\0') ? log_tag : "ELEC_MOTOR";
    return ESP_OK;
}

esp_err_t elec_motor_nmt_send(uint8_t cmd, uint8_t node)
{
    uint8_t d[2] = {cmd, node};
    return can_send(NMT_ID, d, 2);
}

esp_err_t elec_motor_sdo_write_u8(uint16_t idx, uint8_t sub, uint8_t v)
{
    return sdo_write_8b(0x2F, idx, sub, (uint32_t)v);
}

esp_err_t elec_motor_sdo_write_u16(uint16_t idx, uint8_t sub, uint16_t v)
{
    return sdo_write_8b(0x2B, idx, sub, (uint32_t)v);
}

esp_err_t elec_motor_sdo_write_u32(uint16_t idx, uint8_t sub, uint32_t v)
{
    return sdo_write_8b(0x23, idx, sub, v);
}

esp_err_t elec_motor_configure_rpdo1_map_controlword_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1600, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1600, 0x01, 0x60400010));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1600, 0x00, 1));
    ESP_LOGI(s_log_tag, "RPDO1 -> 0x6040 Controlword (16-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_rpdo2_map_target_velocity_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1601, 0x01, 0x60FF0020));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 1));
    ESP_LOGI(s_log_tag, "RPDO2 -> 0x60FF Target velocity (32-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_rpdo2_map_target_velocity_and_cmd_polarity(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1601, 0x01, 0x60FF0020));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1601, 0x02, 0x607E0008));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 2));
    ESP_LOGI(s_log_tag, "RPDO2 -> 0x60FF Target velocity (32-bit) + 0x607E Cmd polarity (8-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_rpdo2_map_target_position_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1601, 0x01, 0x607A0020));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 1));
    ESP_LOGI(s_log_tag, "RPDO2 -> 0x607A Target position (32-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_rpdo2_map_target_position_and_speed(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1601, 0x01, 0x607A0020));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1601, 0x02, 0x60810020));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 2));
    ESP_LOGI(s_log_tag, "RPDO2 -> 0x607A Target position (32-bit), 0x6081 Target speed (32-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_rpdo2_map_target_torque_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1601, 0x01, 0x60710010));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1601, 0x00, 1));
    ESP_LOGI(s_log_tag, "RPDO2 -> 0x6071 Target torque (16-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo1_map_statusword_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A00, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1A00, 0x01, 0x60410010));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A00, 0x00, 1));
    ESP_LOGI(s_log_tag, "TPDO1 -> 0x6041 Statusword (16-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo2_map_current_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A01, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1A01, 0x01, 0x60780010));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A01, 0x00, 1));
    ESP_LOGI(s_log_tag, "TPDO2 -> 0x6078 Current actual value (16-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo2_map_position_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A01, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1A01, 0x01, 0x60640020));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A01, 0x00, 1));
    ESP_LOGI(s_log_tag, "TPDO2 -> 0x6064 Position actual value (32-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo2_inhibit_100hz(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1801, 0x02, 0xFF));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u16(0x1801, 0x03, 100));
    ESP_LOGI(s_log_tag, "TPDO2: transmission=255 (event), inhibit=10ms (~100Hz max)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo2_fast_event(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1801, 0x02, 0xFF));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u16(0x1801, 0x03, 100));
    esp_err_t err = elec_motor_sdo_write_u16(0x1801, 0x05, 15);
    if (err == ESP_OK) {
        ESP_LOGI(s_log_tag, "TPDO2: transmission=255, inhibit(.1ms)=10ms, event=15ms");
        return ESP_OK;
    }

    ESP_LOGW(s_log_tag, "TPDO2: drive rejected event timer (0x1801:04), using inhibit-only timing");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo3_map_velocity_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A02, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1A02, 0x01, 0x606C0020));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A02, 0x00, 1));
    ESP_LOGI(s_log_tag, "TPDO3 -> 0x606C Velocity actual value (32-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo3_fast_event(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1802, 0x02, 0xFF));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u16(0x1802, 0x03, 100));
    esp_err_t err = elec_motor_sdo_write_u16(0x1802, 0x05, 15);
    if (err == ESP_OK) {
        ESP_LOGI(s_log_tag, "TPDO3: transmission=255, inhibit(.1ms)=10ms, event=15ms");
        return ESP_OK;
    }

    ESP_LOGW(s_log_tag, "TPDO3: drive rejected event timer (0x1802:04), using inhibit-only timing");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo4_map_current_only(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A03, 0x00, 0));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x1A03, 0x01, 0x60780010));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1A03, 0x00, 1));
    ESP_LOGI(s_log_tag, "TPDO4 -> 0x6078 Current actual value (16-bit)");
    return ESP_OK;
}

esp_err_t elec_motor_configure_tpdo4_fast_event(void)
{
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x1803, 0x02, 0xFF));
    ESP_ERROR_CHECK(elec_motor_sdo_write_u16(0x1803, 0x03, 100));
    esp_err_t err = elec_motor_sdo_write_u16(0x1803, 0x05, 15);
    if (err == ESP_OK) {
        ESP_LOGI(s_log_tag, "TPDO4: transmission=255, inhibit(.1ms)=10ms, event=15ms");
        return ESP_OK;
    }

    ESP_LOGW(s_log_tag, "TPDO4: drive rejected event timer (0x1803:04), using inhibit-only timing");
    return ESP_OK;
}

esp_err_t elec_motor_send_controlword(uint16_t cw)
{
    uint8_t d[2] = {(uint8_t)(cw & 0xFF), (uint8_t)(cw >> 8)};
    return can_send(RPDO1_ID, d, 2);
}

esp_err_t elec_motor_send_target_velocity(int32_t vel)
{
    vel = vel * 10000 / 60;
    uint8_t d[4] = {
        (uint8_t)(vel & 0xFF),
        (uint8_t)((vel >> 8) & 0xFF),
        (uint8_t)((vel >> 16) & 0xFF),
        (uint8_t)((vel >> 24) & 0xFF),
    };
    return can_send(RPDO2_ID, d, 4);
}

esp_err_t elec_motor_send_target_velocity_and_cmd_polarity(int32_t vel, uint8_t cmd_pol)
{
    vel = vel * 10000 / 60;
    uint8_t d[5] = {
        (uint8_t)(vel & 0xFF),
        (uint8_t)((vel >> 8) & 0xFF),
        (uint8_t)((vel >> 16) & 0xFF),
        (uint8_t)((vel >> 24) & 0xFF),
        cmd_pol,
    };
    return can_send(RPDO2_ID, d, 5);
}

esp_err_t elec_motor_send_target_position(int32_t pos_revs)
{
    int32_t pos = pos_revs * 10000;

    uint8_t d[4] = {
        (uint8_t)(pos & 0xFF),
        (uint8_t)((pos >> 8) & 0xFF),
        (uint8_t)((pos >> 16) & 0xFF),
        (uint8_t)((pos >> 24) & 0xFF),
    };
    return can_send(RPDO2_ID, d, 4);
}

esp_err_t elec_motor_send_target_position_and_speed(float pos_revs, float speed_revs_per_sec)
{
    int32_t pos = (int32_t)lroundf(pos_revs * 10000.0f);
    int32_t speed = (int32_t)lroundf(speed_revs_per_sec * 10000.0f / 60.0f);

    ESP_LOGI(s_log_tag, "POS: %" PRIi32 ", SPEED: %" PRIi32, pos, speed);

    uint8_t d[8] = {
        (uint8_t)(pos & 0xFF),
        (uint8_t)((pos >> 8) & 0xFF),
        (uint8_t)((pos >> 16) & 0xFF),
        (uint8_t)((pos >> 24) & 0xFF),
        (uint8_t)(speed & 0xFF),
        (uint8_t)((speed >> 8) & 0xFF),
        (uint8_t)((speed >> 16) & 0xFF),
        (uint8_t)((speed >> 24) & 0xFF),
    };

    return can_send(RPDO2_ID, d, 8);
}

esp_err_t elec_motor_send_target_torque(int16_t torque)
{
    uint8_t d[2] = {
        (uint8_t)(torque & 0xFF),
        (uint8_t)((torque >> 8) & 0xFF),
    };
    return can_send(RPDO2_ID, d, 2);
}

esp_err_t elec_motor_wait_and_print_tpdo1(uint32_t timeout_ms)
{
    elec_motor_can_rx_item_t item = {0};
    if (!wait_for_id_main(TPDO1_ID, &item, timeout_ms)) {
        ESP_LOGW(s_log_tag, "TPDO1 timeout");
        return ESP_ERR_TIMEOUT;
    }

    elec_motor_log_frame("RX (TPDO1)", item.id, item.data, item.dlc);
    if (item.dlc < 2) {
        ESP_LOGW(s_log_tag, "TPDO1 too short");
        return ESP_FAIL;
    }

    print_statusword(u16_le(&item.data[0]));
    return ESP_OK;
}

esp_err_t elec_motor_enable_operation_sequence(void)
{
    const uint16_t seq[] = {0x0006, 0x0007, 0x000F};
    for (int i = 0; i < 3; i++) {
        ESP_LOGI(s_log_tag, "RPDO1 Controlword = 0x%04X", seq[i]);
        ESP_ERROR_CHECK(elec_motor_send_controlword(seq[i]));
        (void)elec_motor_wait_and_print_tpdo1(TPDO1_WAIT_MS);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
    return ESP_OK;
}

esp_err_t elec_motor_enable_operation_sequence_position(void)
{
    const uint16_t seq[] = {0x0000, 0x0006, 0x0007, 0x000F};
    for (int i = 0; i < 4; i++) {
        ESP_LOGI(s_log_tag, "RPDO1 Controlword = 0x%04X", seq[i]);
        ESP_ERROR_CHECK(elec_motor_send_controlword(seq[i]));
        vTaskDelay(pdMS_TO_TICKS(200));
    }
    return ESP_OK;
}

esp_err_t elec_motor_enable_position(void)
{
    const uint16_t seq[] = {0x006F, 0x007F};
    for (int i = 0; i < 2; i++) {
        ESP_LOGI(s_log_tag, "RPDO1 Controlword = 0x%04X", seq[i]);
        ESP_ERROR_CHECK(elec_motor_send_controlword(seq[i]));
    }
    return ESP_OK;
}
