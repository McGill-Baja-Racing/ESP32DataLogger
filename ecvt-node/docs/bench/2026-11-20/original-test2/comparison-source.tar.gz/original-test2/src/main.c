/**
 * ESP32-P4 + ESP-IDF TWAI (new "node" API) CANopen test harness
 *
 * Servo Node ID = 1
 *
 * Keyboard selectable tests (idf.py monitor):
 *   [1] Test 1: CiA402 state switching using RPDO1(Controlword) + TPDO1(Statusword)
 *   [2] Test 2: Velocity run @ +1000 with TPDO2 position, TPDO3 velocity, TPDO4 current logging
 *   [3] Test 3: Forward @ +1000, stop, reverse via 0x607E bit6, run @ +1000 again
 *   [4] Test 4: Speed steps FWD then REV:
 *       500 (3s) -> 2000 (3s) -> stop (2s) -> flip dir -> 500 (3s) -> 2000 (3s) -> stop (2s)
 *
 * TPDO2/3/4 timing (driver side):
 *   TPDO2/3/4 comm params are configured for event-driven logging.
 *
 * 0x607E (Command polarity, U8):
 *   - bit7: position command polarity (0=positive, 1=negative)
 *   - bit6: velocity command polarity (0=positive, 1=negative)
 *   - mappable, can be changed dynamically in Operational mode
 */

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <sys/stat.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

#include "esp_err.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_vfs_fat.h"

#include "esp_twai.h"
#include "esp_twai_onchip.h"
#include "sdmmc_cmd.h"
#include "driver/sdmmc_host.h"
#include "driver/gpio.h"
#include <math.h>

#include "elec_motor_driver.h"

#if SOC_SDMMC_IO_POWER_EXTERNAL
#include "sd_pwr_ctrl_by_on_chip_ldo.h"
#endif

/* --------------------- User config --------------------- */
#define TAG                 "CANOPEN"

#define TX_GPIO_NUM         5
#define RX_GPIO_NUM         4
#define BITRATE_BPS         500000

#define NODE_ID             1
#define TPDO1_WAIT_MS       400

/* CANopen COB-IDs */
#define TPDO1_ID            (0x180 + NODE_ID)   // servo  -> master
#define TPDO2_ID            (0x280 + NODE_ID)   // servo  -> master
#define TPDO3_ID            (0x380 + NODE_ID)   // servo  -> master
#define TPDO4_ID            (0x480 + NODE_ID)   // servo  -> master
#define EMCY_ID             (0x080 + NODE_ID)   // servo  -> master

#define ECVT_STATUSWORD_TARGET_REACHED (1U << 10)

/* Current monitor */
#define CURR_MAX_PRINT_HZ   100
#define CURR_MIN_PERIOD_MS  (1000 / CURR_MAX_PRINT_HZ)

#define SAMPLE_SIZE         4
#define SAMPLES_PER_BLOCK   100

/* --------------------- Types --------------------- */
typedef struct {
    uint32_t id;
    uint8_t  dlc;
    uint8_t  data[8];
} can_rx_item_t;

typedef struct {
    uint32_t t_us;
    uint32_t val1;
    uint32_t val2;
    uint32_t source_pdo;
} log_sample_t;

typedef enum {
    CMD_HELP = 0,
    CMD_TEST1,
    CMD_TEST2,
    CMD_TEST3,
    CMD_TEST4,
    CMD_TEST5,
} cmd_t;

/* --------------------- Globals --------------------- */
static QueueHandle_t rxq_main    = NULL;   // SDO responses, TPDO1, etc.
static QueueHandle_t rxq_current = NULL;   // TPDO4 current only, length 1, overwrite
static QueueHandle_t rxq_logger  = NULL;   // TPDO2/TPDO3/TPDO4 samples for SD logging
static QueueHandle_t rxq_statusword = NULL; // TPDO1 statusword print queue
static QueueHandle_t rxq_emcy = NULL;      // EMCY error queue
static QueueHandle_t cmdq        = NULL;

static volatile bool monitor_current = false;
static volatile bool logging_active = false;
static volatile bool stop_logging = false;
static volatile uint16_t s_latest_tpdo1_statusword = 0;
static volatile int64_t s_latest_tpdo1_rx_us = 0;

static twai_node_handle_t node_hdl = NULL;
static FILE *log_file = NULL;
static SemaphoreHandle_t log_file_mutex = NULL;
static uint32_t log_buffer[SAMPLES_PER_BLOCK][SAMPLE_SIZE];
static int write_counter = 0;
static char log_path[64] = {0};

static twai_onchip_node_config_t node_cfg = {
    .io_cfg.tx = TX_GPIO_NUM,
    .io_cfg.rx = RX_GPIO_NUM,
    .bit_timing.bitrate = BITRATE_BPS,
    .tx_queue_depth = 8,
};

/* --------------------- Helpers --------------------- */
static uint16_t u16_le(const uint8_t *b) { return (uint16_t)(b[0] | (uint16_t)(b[1] << 8)); }
static uint32_t u32_le(const uint8_t *b)
{
    return (uint32_t)b[0] |
           ((uint32_t)b[1] << 8) |
           ((uint32_t)b[2] << 16) |
           ((uint32_t)b[3] << 24);
}

static void log_statusword(uint16_t sw)
{
    ESP_LOGI(TAG,
             "TPDO1 statusword=0x%04X | Rdy:%d SwOn:%d OpEn:%d Fault:%d QS:%d SoD:%d Warn:%d",
             sw,
             (sw >> 0) & 1,
             (sw >> 1) & 1,
             (sw >> 2) & 1,
             (sw >> 3) & 1,
             (sw >> 5) & 1,
             (sw >> 6) & 1,
             (sw >> 7) & 1);
}

static void close_log_file_if_open(void)
{
    if (log_file) {
        fflush(log_file);
        fclose(log_file);
        log_file = NULL;
        ESP_LOGI(TAG, "Log file closed.");
    }
}

static bool reopen_log_file_append(const char *path)
{
    FILE *reopened = fopen(path, "ab");
    if (!reopened) {
        ESP_LOGE(TAG, "Failed to reopen log file: %s", path);
        return false;
    }

    log_file = reopened;
    ESP_LOGI(TAG, "Log file reopened.");
    return true;
}

static void write_log_block(const uint32_t (*buf)[SAMPLE_SIZE], size_t sample_count)
{
    const size_t bytes = sample_count * SAMPLE_SIZE * sizeof(uint32_t);

    if (xSemaphoreTake(log_file_mutex, portMAX_DELAY) != pdTRUE) {
        ESP_LOGE(TAG, "Failed to lock log file mutex");
        return;
    }

    if (!log_file) {
        xSemaphoreGive(log_file_mutex);
        ESP_LOGE(TAG, "Log file is not open");
        return;
    }

    size_t written = fwrite(buf, 1, bytes, log_file);
    fflush(log_file);
    xSemaphoreGive(log_file_mutex);

    if (written != bytes) {
        ESP_LOGE(TAG, "Short write! wrote=%u expected=%u",
                 (unsigned)written, (unsigned)bytes);
        return;
    }

    write_counter++;
    ESP_LOGI(TAG, "Wrote block %d (%u bytes, %u samples)",
             write_counter, (unsigned)bytes, (unsigned)sample_count);
}

static void create_unique_log_filename(char *out_path, size_t max_len)
{
    int index = 1;
    struct stat st;

    while (1) {
        snprintf(out_path, max_len, "/sdcard/log_%04d.bin", index);
        if (stat(out_path, &st) != 0) {
            return;
        }
        index++;
    }
}

static void stop_sd_logging(void)
{
    stop_logging = true;
}

static void start_logging_window(void)
{
    logging_active = true;
}

static void stop_logging_window(void)
{
    logging_active = false;
}

static bool wait_for_target_reached_after(int64_t command_start_us,
                                          uint32_t timeout_ms,
                                          uint32_t *elapsed_ms_out)
{
    const int64_t deadline_us = command_start_us + ((int64_t)timeout_ms * 1000);

    while (esp_timer_get_time() < deadline_us) {
        const uint16_t statusword = s_latest_tpdo1_statusword;
        const int64_t latest_rx_us = s_latest_tpdo1_rx_us;

        if (latest_rx_us >= command_start_us &&
            (statusword & ECVT_STATUSWORD_TARGET_REACHED) != 0U) {
            if (elapsed_ms_out) {
                *elapsed_ms_out = (uint32_t)((latest_rx_us - command_start_us) / 1000);
            }
            return true;
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }

    return false;
}

/* --------------------- TWAI RX ISR callback --------------------- */
static bool twai_rx_cb(twai_node_handle_t node,
                       const twai_rx_done_event_data_t *edata,
                       void *user_ctx)
{
    (void)edata;
    (void)user_ctx;

    BaseType_t hp_woken = pdFALSE;

    uint8_t raw[8] = {0};
    twai_frame_t fr = {
        .buffer = raw,
        .buffer_len = sizeof(raw),
    };

    if (twai_node_receive_from_isr(node, &fr) == ESP_OK) {
        can_rx_item_t item = {0};
        item.id  = fr.header.id;
        item.dlc = fr.buffer_len > 8 ? 8 : fr.buffer_len;
        memcpy(item.data, raw, item.dlc);

        if (item.id == TPDO1_ID) {
            if (item.dlc >= 2) {
                s_latest_tpdo1_statusword = u16_le(&item.data[0]);
                s_latest_tpdo1_rx_us = esp_timer_get_time();
            }
            xQueueSendFromISR(rxq_main, &item, &hp_woken);
            if (rxq_statusword) {
                xQueueSendFromISR(rxq_statusword, &item, &hp_woken);
            }
        } else if (item.id == EMCY_ID) {
            if (rxq_emcy) {
                xQueueSendFromISR(rxq_emcy, &item, &hp_woken);
            }
        } else if (item.id == TPDO2_ID) {
            if (!stop_logging && logging_active && rxq_logger) {
                log_sample_t s = {0};
                s.t_us = (uint32_t)esp_timer_get_time();
                s.val1 = item.dlc >= 4 ? u32_le(&item.data[0]) : 0;
                s.val2 = 0;
                s.source_pdo = 2;
                xQueueSendFromISR(rxq_logger, &s, &hp_woken);
            }
        } else if (item.id == TPDO3_ID) {
            if (!stop_logging && logging_active && rxq_logger) {
                log_sample_t s = {0};
                s.t_us = (uint32_t)esp_timer_get_time();
                s.val1 = item.dlc >= 4 ? u32_le(&item.data[0]) : 0;
                s.val2 = 0;
                s.source_pdo = 3;
                xQueueSendFromISR(rxq_logger, &s, &hp_woken);
            }
        } else if (item.id == TPDO4_ID) {
            if (!stop_logging && logging_active && rxq_logger) {
                log_sample_t s = {0};
                s.t_us = (uint32_t)esp_timer_get_time();
                s.val1 = item.dlc >= 2 ? (uint32_t)(int32_t)(int16_t)u16_le(&item.data[0]) : 0;
                s.val2 = 0;
                s.source_pdo = 4;
                xQueueSendFromISR(rxq_logger, &s, &hp_woken);
            }
            if (monitor_current) {
                xQueueOverwriteFromISR(rxq_current, &item, &hp_woken);
            }
        } else {
            xQueueSendFromISR(rxq_main, &item, &hp_woken);
        }
    }

    return hp_woken == pdTRUE;
}

static twai_event_callbacks_t cbs = {
    .on_rx_done = twai_rx_cb,
};

/* --------------------- CAN send helper --------------------- */
static void save_task(void *arg)
{
    const char *path = (const char *)arg;
    TickType_t last_wake_time = xTaskGetTickCount();

    while (1) {
        vTaskDelayUntil(&last_wake_time, pdMS_TO_TICKS(15000));

        if (xSemaphoreTake(log_file_mutex, portMAX_DELAY) != pdTRUE) {
            ESP_LOGE(TAG, "Failed to lock log file mutex");
            continue;
        }

        if (log_file) {
            ESP_LOGI(TAG, "File saved");
            close_log_file_if_open();
            if (!reopen_log_file_append(path)) {
                stop_logging = true;
            }
        } else if (stop_logging) {
            xSemaphoreGive(log_file_mutex);
            ESP_LOGI(TAG, "save_task done.");
            vTaskDelete(NULL);
            return;
        }

        xSemaphoreGive(log_file_mutex);
    }
}

static void sd_writer_task(void *arg)
{
    const char *path = (const char *)arg;
    size_t sample_index = 0;

    ESP_LOGI(TAG, "Creating log file: %s", path);
    if (xSemaphoreTake(log_file_mutex, portMAX_DELAY) != pdTRUE) {
        ESP_LOGE(TAG, "Failed to lock log file mutex");
        stop_logging = true;
        vTaskDelete(NULL);
        return;
    }

    log_file = fopen(path, "wb");
    if (!log_file) {
        xSemaphoreGive(log_file_mutex);
        ESP_LOGE(TAG, "Failed to open log file");
        stop_logging = true;
        vTaskDelete(NULL);
        return;
    }
    xSemaphoreGive(log_file_mutex);

    while (1) {
        log_sample_t msg = {0};
        BaseType_t got_sample = xQueueReceive(rxq_logger, &msg, pdMS_TO_TICKS(100));

        if (got_sample == pdTRUE && !stop_logging) {
            log_buffer[sample_index][0] = msg.t_us;
            log_buffer[sample_index][1] = msg.val1;
            log_buffer[sample_index][2] = msg.val2;
            log_buffer[sample_index][3] = msg.source_pdo;
            sample_index++;

            if (sample_index >= SAMPLES_PER_BLOCK) {
                write_log_block(log_buffer, sample_index);
                sample_index = 0;
            }
        }

        if (stop_logging && uxQueueMessagesWaiting(rxq_logger) == 0) {
            if (sample_index > 0) {
                ESP_LOGI(TAG, "Flushing partial block (%u samples)...", (unsigned)sample_index);
                write_log_block(log_buffer, sample_index);
            }

            (void)xSemaphoreTake(log_file_mutex, portMAX_DELAY);
            close_log_file_if_open();
            xSemaphoreGive(log_file_mutex);

            ESP_LOGI(TAG, "sd_writer_task done.");
            vTaskDelete(NULL);
            return;
        }
    }
}

/* --------------------- Current monitor task (TPDO4) --------------------- */
static void monitor_current_task(void *arg)
{
    (void)arg;

    const TickType_t min_period = pdMS_TO_TICKS(CURR_MIN_PERIOD_MS);
    TickType_t last_print = 0;

    bool have_prev = false;
    int16_t prev_raw = 0;

    while (1) {
        can_rx_item_t item;
        if (xQueueReceive(rxq_current, &item, pdMS_TO_TICKS(500)) != pdTRUE) {
            continue;
        }
        if (!monitor_current) continue;
        if (item.dlc < 2) continue;

        int16_t raw = (int16_t)u16_le(&item.data[0]);

        if (have_prev && raw == prev_raw) continue;

        TickType_t now = xTaskGetTickCount();
        if (last_print != 0 && (now - last_print) < min_period) {
            prev_raw = raw;
            have_prev = true;
            continue;
        }

        last_print = now;
        prev_raw = raw;
        have_prev = true;

        float pct = raw / 10.0f;  // typical 0.1% rated current scaling
        ESP_LOGI(TAG, "TPDO4 Iraw=%d (%.1f%% rated)", raw, pct);
    }
}

static void statusword_logger_task(void *arg)
{
    (void)arg;

    while (1) {
        can_rx_item_t item;
        if (xQueueReceive(rxq_statusword, &item, portMAX_DELAY) != pdTRUE) {
            continue;
        }
        if (item.dlc < 2) {
            continue;
        }

        elec_motor_log_frame("RX (TPDO1)", item.id, item.data, item.dlc);
        log_statusword(u16_le(&item.data[0]));
    }
}

static void emcy_logger_task(void *arg)
{
    (void)arg;

    while (1) {
        can_rx_item_t item;
        if (xQueueReceive(rxq_emcy, &item, portMAX_DELAY) != pdTRUE) {
            continue;
        }
        if (item.dlc < 2) {
            continue;
        }

        const uint16_t error_code = u16_le(&item.data[0]);
        elec_motor_log_frame("RX (EMCY)", item.id, item.data, item.dlc);
        ESP_LOGE(TAG, "Servo EMCY received: error_code=0x%04X", error_code);
    }
}

/* --------------------- Tests --------------------- */
static void run_test1(void *arg)
{
    ESP_LOGI(TAG, "====================");
    ESP_LOGI(TAG, "TEST 1: State switching (RPDO1/TPDO1)");
    ESP_LOGI(TAG, "====================");

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x80, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_configure_rpdo1_map_controlword_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo1_map_statusword_only());

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x01, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_enable_operation_sequence());

    //ESP_ERROR_CHECK(elec_motor_send_controlword(0x0000));
    //(void)elec_motor_wait_and_print_tpdo1(TPDO1_WAIT_MS);
    //stop_sd_logging();

    ESP_LOGI(TAG, "TEST 1 done.");

    while(1){

    }
}

static void run_test2(void *arg)
{
    ESP_LOGI(TAG, "====================");
    ESP_LOGI(TAG, "TEST 2: Velocity mode with TPDO2 position, TPDO3 velocity, TPDO4 current");
    ESP_LOGI(TAG, "====================");

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x80, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_configure_rpdo1_map_controlword_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo1_map_statusword_only());
    ESP_ERROR_CHECK(elec_motor_configure_rpdo2_map_target_velocity_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_map_position_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_inhibit_100hz());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_map_velocity_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_map_current_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_fast_event());

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x01, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_enable_operation_sequence());

    ESP_LOGI(TAG, "VELOCITY MODE");
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x6060, 0x00, 3)); // velocity mode

    start_logging_window();
    monitor_current = false;
    ESP_LOGI(TAG, "VELOCITY GO!");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity(1000));
    vTaskDelay(pdMS_TO_TICKS(3000));

    ESP_LOGI(TAG, "VELOCITY GO!");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity(0));
    vTaskDelay(pdMS_TO_TICKS(1000));

    monitor_current = false;
    stop_logging_window();

    ESP_ERROR_CHECK(elec_motor_send_controlword(0x0000));
    (void)elec_motor_wait_and_print_tpdo1(TPDO1_WAIT_MS);
    stop_sd_logging();

    ESP_LOGI(TAG, "TEST 2 done.");

    while(1){

    }
}

static void run_test3(void *arg)
{
    ESP_LOGI(TAG, "====================");
    ESP_LOGI(TAG, "TEST 3: Forward @+1000, stop, reverse via 0x607E(bit6), run @+1000");
    ESP_LOGI(TAG, "====================");

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x80, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_configure_rpdo1_map_controlword_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo1_map_statusword_only());
    ESP_ERROR_CHECK(elec_motor_configure_rpdo2_map_target_velocity_and_cmd_polarity());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_map_position_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_inhibit_100hz());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_map_velocity_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_map_current_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_fast_event());

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x01, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_enable_operation_sequence());
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x6060, 0x00, 3)); // velocity mode

    const uint8_t CMDPOL_FWD = 0x00;
    const uint8_t CMDPOL_REV = (1u << 6); // 0x40

    start_logging_window();
    monitor_current = true;

    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(1000, CMDPOL_FWD));
    vTaskDelay(pdMS_TO_TICKS(2500));

    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(0, CMDPOL_FWD));
    vTaskDelay(pdMS_TO_TICKS(800));

    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(0, CMDPOL_REV));
    vTaskDelay(pdMS_TO_TICKS(200));

    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(1000, CMDPOL_REV));
    vTaskDelay(pdMS_TO_TICKS(2500));

    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(0, CMDPOL_REV));
    vTaskDelay(pdMS_TO_TICKS(600));

    monitor_current = false;
    stop_logging_window();

    ESP_ERROR_CHECK(elec_motor_send_controlword(0x0000));
    (void)elec_motor_wait_and_print_tpdo1(TPDO1_WAIT_MS);
    stop_sd_logging();

    ESP_LOGI(TAG, "TEST 3 done.");

    while(1){

    }
}

/* NEW: Test 4 per your sequence */
static void run_test4(void *arg)
{
    ESP_LOGI(TAG, "====================");
    ESP_LOGI(TAG, "TEST 4: 500->2000->stop then reverse 500->2000->stop (via 0x607E bit6)");
    ESP_LOGI(TAG, "====================");

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x80, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_configure_rpdo1_map_controlword_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo1_map_statusword_only());
    ESP_ERROR_CHECK(elec_motor_configure_rpdo2_map_target_velocity_and_cmd_polarity());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_map_position_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_inhibit_100hz());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_map_velocity_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_map_current_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_fast_event());

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x01, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_enable_operation_sequence());
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x6060, 0x00, 3)); // velocity mode

    const uint8_t CMDPOL_FWD = 0x00;
    const uint8_t CMDPOL_REV = (1u << 6); // 0x40

    start_logging_window();
    monitor_current = true;

    // ---- Forward ----
    ESP_LOGI(TAG, "[FWD] 500 for 3s");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(500, CMDPOL_FWD));
    vTaskDelay(pdMS_TO_TICKS(3000));

    ESP_LOGI(TAG, "[FWD] 2000 for 3s");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(2000, CMDPOL_FWD));
    vTaskDelay(pdMS_TO_TICKS(3000));

    ESP_LOGI(TAG, "[FWD] stop for 2s");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(0, CMDPOL_FWD));
    vTaskDelay(pdMS_TO_TICKS(2000));

    // ---- Switch direction while stopped ----
    ESP_LOGI(TAG, "Switch direction: set 0x607E bit6 (REV) while stopped");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(0, CMDPOL_REV));
    vTaskDelay(pdMS_TO_TICKS(200));

    // ---- Reverse ----
    ESP_LOGI(TAG, "[REV] 500 for 3s");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(500, CMDPOL_REV));
    vTaskDelay(pdMS_TO_TICKS(3000));

    ESP_LOGI(TAG, "[REV] 2000 for 3s");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(2000, CMDPOL_REV));
    vTaskDelay(pdMS_TO_TICKS(3000));

    ESP_LOGI(TAG, "[REV] stop for 2s");
    ESP_ERROR_CHECK(elec_motor_send_target_velocity_and_cmd_polarity(0, CMDPOL_REV));
    vTaskDelay(pdMS_TO_TICKS(2000));

    monitor_current = false;
    stop_logging_window();

    ESP_ERROR_CHECK(elec_motor_send_controlword(0x0000));
    (void)elec_motor_wait_and_print_tpdo1(TPDO1_WAIT_MS);
    stop_sd_logging();

    ESP_LOGI(TAG, "TEST 4 done.");

    while(1){

    }
}

static void run_test5(void *arg)
{
    (void)arg;
    const int16_t target_torque = 10;

    ESP_LOGI(TAG, "====================");
    ESP_LOGI(TAG, "TEST 5: Torque mode single command");
    ESP_LOGI(TAG, "====================");

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x80, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_ERROR_CHECK(elec_motor_configure_rpdo1_map_controlword_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo1_map_statusword_only());
    ESP_ERROR_CHECK(elec_motor_configure_rpdo2_map_target_torque_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_map_position_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_map_velocity_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_map_current_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_fast_event());

    ESP_ERROR_CHECK(elec_motor_nmt_send(0x01, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_LOGI(TAG, "TORQUE MODE");
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x6060, 0x00, 4)); // profile torque mode
    ESP_ERROR_CHECK(elec_motor_enable_operation_sequence());

    //start_logging_window();
    monitor_current = true;

    ESP_LOGI(TAG, "Sending target torque command: %d", target_torque);
    ESP_ERROR_CHECK(elec_motor_send_target_torque(target_torque));
    vTaskDelay(pdMS_TO_TICKS(10000));

    monitor_current = false;
    stop_logging_window();

    //ESP_ERROR_CHECK(elec_motor_send_controlword(0x0000));
    (void)elec_motor_wait_and_print_tpdo1(TPDO1_WAIT_MS);
    //stop_sd_logging();

    ESP_LOGI(TAG, "TEST 5 done.");

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

static void run_test(void *arg)
{
    (void)arg;

    ESP_LOGI(TAG, "====================");
    ESP_LOGI(TAG, "TEST: Step input + record TPDO2 position, TPDO3 velocity, TPDO4 current to SD");
    ESP_LOGI(TAG, "====================");

    // Go pre-op
    ESP_ERROR_CHECK(elec_motor_nmt_send(0x80, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    // Configure PDO mappings
    ESP_ERROR_CHECK(elec_motor_configure_rpdo1_map_controlword_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo1_map_statusword_only());
    ESP_ERROR_CHECK(elec_motor_configure_rpdo2_map_target_position_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_map_position_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_map_velocity_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_map_current_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_fast_event());

    // Start node
    ESP_ERROR_CHECK(elec_motor_nmt_send(0x01, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    // Profile Position mode (1)
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x6060, 0x00, 1));

    // Set motion profile via SDO (so PDO stays <= 8 bytes)
    // Using your scaling convention (same as you used for velocity earlier):
    // vel/acc/dec here are in rpm-ish scaled units depending on drive; keep consistent with your drive settings.
    ESP_LOGI(TAG, "Configure profile velocity/acc/dec via SDO");
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x6081, 0x00, (uint32_t)(1000 * 10000 / 60))); // Profile velocity
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x6083, 0x00, (uint32_t)( 500 * 10000 / 60))); // Profile acceleration
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x6084, 0x00, (uint32_t)( 100 * 10000 / 60))); // Profile deceleration

    // Enable operation
     ESP_LOGI(TAG, "Enable Motor");
    ESP_ERROR_CHECK(elec_motor_enable_operation_sequence_position());
    vTaskDelay(pdMS_TO_TICKS(1000));

    start_logging_window();
    // Step command: send target position
    ESP_LOGI(TAG, "Sending target position step...");
    ESP_ERROR_CHECK(elec_motor_send_target_position(100)); // 10 rev in your 10000 units/rev convention

    // Stop motor
    vTaskDelay(pdMS_TO_TICKS(12000));
    stop_logging_window();
    ESP_ERROR_CHECK(elec_motor_send_controlword(0x0000));
    stop_sd_logging();
    ESP_LOGI(TAG, "TEST done.");

    // Keep task alive until logging stops
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(200));
    }
    vTaskDelete(NULL);
}

static void run_pos_test(void *arg)
{
    (void)arg;
    const float target_position_revs = 75.0f;
    const float target_speed_rpm = 2000.0f;       
    const float target_accel = 1666.0f;         // rpm/s.   Max = 25769803
    const float target_decel = 1666.0f;         // rpm/s
    const uint32_t profile_accel = (uint32_t)(((double)target_accel * 10000.0) / 60.0);
    const uint32_t profile_decel = (uint32_t)(((double)target_decel * 10000.0) / 60.0);
    const uint32_t move_timeout_ms = 20000;

    ESP_LOGI(TAG, "====================");
    ESP_LOGI(TAG, "TEST: Step input + record TPDO2 position, TPDO3 velocity, TPDO4 current to SD");
    ESP_LOGI(TAG, "====================");

    // Go pre-op
    ESP_ERROR_CHECK(elec_motor_nmt_send(0x80, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    // Configure PDO mappings
    ESP_ERROR_CHECK(elec_motor_configure_rpdo1_map_controlword_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo1_map_statusword_only());
    ESP_ERROR_CHECK(elec_motor_configure_rpdo2_map_target_position_and_speed());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_map_position_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo2_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_map_velocity_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo3_fast_event());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_map_current_only());
    ESP_ERROR_CHECK(elec_motor_configure_tpdo4_fast_event());

    // Start node
    ESP_ERROR_CHECK(elec_motor_nmt_send(0x01, (uint8_t)NODE_ID));
    vTaskDelay(pdMS_TO_TICKS(100));

    // Profile Position mode (1)
    ESP_ERROR_CHECK(elec_motor_sdo_write_u8(0x6060, 0x00, 1));

    // Set motion profile via SDO (so PDO stays <= 8 bytes)
    // Using your scaling convention (same as you used for velocity earlier):
    // vel/acc/dec here are in rpm-ish scaled units depending on drive; keep consistent with your drive settings.
    ESP_LOGI(TAG, "Configure profile acc/dec via SDO");
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x6083, 0x00, profile_accel)); // Profile acceleration
    ESP_ERROR_CHECK(elec_motor_sdo_write_u32(0x6084, 0x00, profile_decel)); // Profile deceleration

    vTaskDelay(pdMS_TO_TICKS(1000));

    // Enable operation
     ESP_LOGI(TAG, "Enable Motor");
    ESP_ERROR_CHECK(elec_motor_enable_operation_sequence_position());
    vTaskDelay(pdMS_TO_TICKS(1000));

    // Going to 0
    // ESP_ERROR_CHECK(elec_motor_send_target_position_and_speed(0, 3000));
    // ESP_ERROR_CHECK(elec_motor_enable_position());
    // vTaskDelay(pdMS_TO_TICKS(10000));

    s_latest_tpdo1_statusword = 0;
    s_latest_tpdo1_rx_us = 0;
    start_logging_window();

    const int64_t command_start_us = esp_timer_get_time();
    ESP_LOGI(TAG, "Sending target position %.2f rev at %.2f rpm and starting log window",
             target_position_revs, target_speed_rpm);
    ESP_ERROR_CHECK(elec_motor_send_target_position_and_speed(target_position_revs, target_speed_rpm));
    ESP_ERROR_CHECK(elec_motor_enable_position());


    uint32_t elapsed_ms = 0;
    const bool target_reached = wait_for_target_reached_after(command_start_us,
                                                              move_timeout_ms,
                                                              &elapsed_ms);

    //vTaskDelay(pdMS_TO_TICKS(3000));                                                         
    stop_logging_window();

    if (target_reached) {
        ESP_LOGI(TAG, "Target reached in %u ms (statusword=0x%04X)",
                 elapsed_ms,
                 s_latest_tpdo1_statusword);
    } else {
        ESP_LOGW(TAG, "Timed out after %u ms waiting for target reached (last statusword=0x%04X)",
                 move_timeout_ms,
                 s_latest_tpdo1_statusword);
    }

    // Stop motor
    vTaskDelay(pdMS_TO_TICKS(250));
    ESP_ERROR_CHECK(elec_motor_send_controlword(0x0000));
    stop_sd_logging();
    ESP_LOGI(TAG, "TEST done.");

    // Keep task alive until logging stops
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(200));
    }
    vTaskDelete(NULL);
}

/* --------------------- Console + runner --------------------- */
static void print_menu(void)
{
    ESP_LOGI(TAG, "=== Menu ===");
    ESP_LOGI(TAG, "  1 : Test 1 (state switching RPDO1/TPDO1)");
    ESP_LOGI(TAG, "  2 : Test 2 (velocity + TPDO2 position + TPDO3 velocity + TPDO4 current)");
    ESP_LOGI(TAG, "  3 : Test 3 (forward-stop-reverse using 0x607E bit6 in RPDO2)");
    ESP_LOGI(TAG, "  4 : Test 4 (500->2000->stop then reverse 500->2000->stop)");
    ESP_LOGI(TAG, "  5 : Test 5 (torque mode single torque command)");
    ESP_LOGI(TAG, "  h : help");
    ESP_LOGI(TAG, "Type a key in idf.py monitor and press Enter (monitor may echo).");
}

static void console_task(void *arg)
{
    (void)arg;
    print_menu();

    while (1) {
        int c = getchar();
        if (c < 0) continue;

        cmd_t cmd = CMD_HELP;
        if      (c == '1') cmd = CMD_TEST1;
        else if (c == '2') cmd = CMD_TEST2;
        else if (c == '3') cmd = CMD_TEST3;
        else if (c == '4') cmd = CMD_TEST4;
        else if (c == '5') cmd = CMD_TEST5;
        else if (c == 'h' || c == 'H') cmd = CMD_HELP;
        else continue;

        xQueueSend(cmdq, &cmd, portMAX_DELAY);
    }
}

// static void test_runner_task(void *arg)
// {
//     (void)arg;

//     while (1) {
//         cmd_t cmd;
//         if (xQueueReceive(cmdq, &cmd, portMAX_DELAY) != pdTRUE) continue;

//         switch (cmd) {
//             case CMD_HELP:  print_menu(); break;
//             case CMD_TEST1: run_test1(); break;
//             case CMD_TEST2: run_test2(); break;
//             case CMD_TEST3: run_test3(); break;
//             case CMD_TEST4: run_test4(); break;
//             case CMD_TEST5: run_test5(); break;
//             default: break;
//         }
//     }
// }

static void original_test2_gate(void *arg)
{
    (void)arg;
    ESP_LOGI(TAG, "COMPARISON READY: original Test 2; send 2 to start once. 1000 rpm for 3 s, then zero and disable.");
    while (true) {
        const int command = getchar();
        if (command == '2') {
            run_test2(NULL);
            vTaskDelete(NULL);
            return;
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

/* --------------------- app_main --------------------- */
void app_main(void)
{
    ESP_LOGI(TAG, "Initializing SD card...");

    esp_vfs_fat_sdmmc_mount_config_t mount_config = {
        .format_if_mount_failed = false,
        .max_files = 5,
        .allocation_unit_size = 16 * 1024,
    };

    sdmmc_card_t *card = NULL;

    sdmmc_host_t host = SDMMC_HOST_DEFAULT();
    host.slot = SDMMC_HOST_SLOT_0;

#if SOC_SDMMC_IO_POWER_EXTERNAL
    sd_pwr_ctrl_ldo_config_t cfg = {0};
    cfg.ldo_chan_id = 4;

    sd_pwr_ctrl_handle_t pwr = NULL;
    esp_err_t pwr_err = sd_pwr_ctrl_new_on_chip_ldo(&cfg, &pwr);
    if (pwr_err == ESP_OK) {
        host.pwr_ctrl_handle = pwr;
        ESP_LOGI(TAG, "SD IO power control enabled (on-chip LDO chan %d)", cfg.ldo_chan_id);
    } else {
        ESP_LOGW(TAG, "SD IO power control NOT enabled: %s", esp_err_to_name(pwr_err));
    }
#endif

    sdmmc_slot_config_t slot_config = SDMMC_SLOT_CONFIG_DEFAULT();
    slot_config.width = 4;
    slot_config.clk = (gpio_num_t)43;
    slot_config.cmd = (gpio_num_t)44;
    slot_config.d0  = (gpio_num_t)39;
    slot_config.d1  = (gpio_num_t)40;
    slot_config.d2  = (gpio_num_t)41;
    slot_config.d3  = (gpio_num_t)42;
    slot_config.flags |= SDMMC_SLOT_FLAG_INTERNAL_PULLUP;
    slot_config.cd = SDMMC_SLOT_NO_CD;
    slot_config.wp = SDMMC_SLOT_NO_WP;

    vTaskDelay(pdMS_TO_TICKS(30));

    esp_err_t err = esp_vfs_fat_sdmmc_mount("/sdcard", &host, &slot_config, &mount_config, &card);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "Comparison: no SD card (%s); serial diagnostics only", esp_err_to_name(err));
        stop_logging = true;
    } else {
        sdmmc_card_print_info(stdout, card);
        create_unique_log_filename(log_path, sizeof(log_path));
        ESP_LOGI(TAG, "Log path: %s", log_path);
    }

    rxq_main    = xQueueCreate(64, sizeof(can_rx_item_t));
    rxq_current = xQueueCreate(1,  sizeof(can_rx_item_t));  // overwrite queue for TPDO4 current
    rxq_logger  = xQueueCreate(256, sizeof(log_sample_t));
    rxq_statusword = xQueueCreate(64, sizeof(can_rx_item_t));
    rxq_emcy    = xQueueCreate(16, sizeof(can_rx_item_t));
    cmdq        = xQueueCreate(8,  sizeof(cmd_t));
    log_file_mutex = xSemaphoreCreateMutex();

    if (!rxq_main || !rxq_current || !rxq_logger || !rxq_statusword || !rxq_emcy || !cmdq || !log_file_mutex) {
        ESP_LOGE(TAG, "Queue or mutex create failed");
        return;
    }

    ESP_ERROR_CHECK(twai_new_node_onchip(&node_cfg, &node_hdl));
    ESP_LOGI(TAG, "TWAI node created");

    ESP_ERROR_CHECK(twai_node_register_event_callbacks(node_hdl, &cbs, NULL));
    ESP_LOGI(TAG, "TWAI callbacks registered");

    ESP_ERROR_CHECK(twai_node_enable(node_hdl));
    ESP_LOGI(TAG, "TWAI enabled (bitrate=%d, NodeID=%d)", BITRATE_BPS, NODE_ID);

    ESP_ERROR_CHECK(elec_motor_driver_init(node_hdl, rxq_main, NODE_ID, TAG));
    ESP_LOGI(TAG, "Motor driver initialized");

    if (err == ESP_OK) {
        xTaskCreate(sd_writer_task, "sd_writer", 8192, (void *)log_path, 8, NULL);
        xTaskCreate(save_task, "save_task", 4096, (void *)log_path, 8, NULL);
    }
    xTaskCreate(statusword_logger_task, "tpdo1_logger",  4096, NULL, 8, NULL);
    xTaskCreate(emcy_logger_task,     "emcy_logger",     4096, NULL, 8, NULL);
    //xTaskCreate(monitor_current_task, "monitor_current", 4096, NULL, 9, NULL);
    xTaskCreate(original_test2_gate, "original_test2", 8192, NULL, 8, NULL);
    //xTaskCreate(console_task,         "console",         4096, NULL, 5, NULL);

    ESP_LOGI(TAG, "Ready. Use keyboard to run tests.");
}
