# Transfer SD Logs

This project now includes a separate host-side script:

- `pull_sd_logs.py`

It does not modify firmware or existing decoder files. It copies `.bin` log files from a mounted SD card volume to your computer.

Examples:

```bash
python3 pull_sd_logs.py
python3 pull_sd_logs.py --latest
python3 pull_sd_logs.py --volume /Volumes/NO_NAME
python3 pull_sd_logs.py --volume /Volumes/NO_NAME --dest ./Data
```

Notes:

- On macOS, SD cards usually appear under `/Volumes/...`
- The script looks for `log_*.bin` and `LOG_*.BIN`
- If multiple mounted volumes match, pass `--volume` explicitly
