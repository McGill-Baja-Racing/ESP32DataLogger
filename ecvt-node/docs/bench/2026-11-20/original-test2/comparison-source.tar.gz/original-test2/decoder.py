#!/usr/bin/env python3
import csv
import struct
from pathlib import Path

REC = struct.Struct("<IIII")  # raw record: t_us, val1, val2, source_pdo
REC_SIZE = REC.size           # 16 bytes
RATED_CURRENT_A = 5.2
CURRENT_SCALE_A_PER_UNIT = RATED_CURRENT_A * 0.001  # 1 unit = 0.1% of rated current
POSITION_SCALE_REV_PER_UNIT = 1.0 / 10000.0
TIMESTAMP_SCALE_MS_PER_US = 1.0 / 1000.0

def u32_to_i32(x: int) -> int:
    x &= 0xFFFFFFFF
    return x - 0x100000000 if (x & 0x80000000) else x

def decode_p4_log(bin_path: Path, csv_path: Path) -> None:
    data = bin_path.read_bytes()
    n = len(data)
    usable = n - (n % REC_SIZE)
    if usable != n:
        print(f"Warning: ignoring {n - usable} trailing bytes (incomplete record).")

    # latest known values (stateful merge)
    last_vel = None
    last_pos_rev = None
    last_cur_a = None

    with csv_path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["timestamp_ms", "velocity", "position_rev", "current_a"])

        for off in range(0, usable, REC_SIZE):
            t_us, val1, val2, source_pdo = REC.unpack_from(data, off)

            if source_pdo == 2:
                last_pos_rev = u32_to_i32(val1) * POSITION_SCALE_REV_PER_UNIT
            elif source_pdo == 3:
                last_vel = u32_to_i32(val1)
            elif source_pdo == 4:
                last_cur_a = u32_to_i32(val1) * CURRENT_SCALE_A_PER_UNIT

            w.writerow([
                t_us * TIMESTAMP_SCALE_MS_PER_US,
                "" if last_vel is None else last_vel,
                "" if last_pos_rev is None else last_pos_rev,
                "" if last_cur_a is None else last_cur_a,
            ])

    print(f"Wrote: {csv_path}")

if __name__ == "__main__":
    decode_p4_log(
        Path("./Data/LOG_0172.BIN"),
        Path("./Data/LOG_0172.csv"),
    )
